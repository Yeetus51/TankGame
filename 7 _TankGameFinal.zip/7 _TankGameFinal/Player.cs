﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GXPEngine;

public class Player : Entity
{
    public Player(Vec2 pPos, int pRadius, Int32 pColor): base(pPos, pRadius, pColor)
    {

    }
    void Update()
    {
        base.Update();
    }

    public override void Shooting()
    {
        if (Input.GetMouseButtonDown(1))
        {
            MyGame myGame = (MyGame)game;
            for (int i = 0; i < myGame.GetNumberOfMovers(); i++)
            {
                Ball mover = myGame.GetMover(i);
                Vec2 explosionForce = mover.position - position;
                explosionForce.SetLength(Mathf.Pow(25/Mathf.Sqrt(explosionForce.Length()),2)); 
                mover.velocity += explosionForce;
            }
        }


        if (Input.GetMouseButtonDown(0))
        {
            base.Shooting();
        }
    }
}
