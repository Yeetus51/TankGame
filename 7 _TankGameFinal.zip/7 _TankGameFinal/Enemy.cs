﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GXPEngine;
public class Enemy : Entity
{
    MyGame myGame;
    Player player;
    //NLineSegment line; 
    int time = 0;
    public Enemy(Vec2 pPos, int pRadius, Int32 pColor) : base(pPos, pRadius, pColor)
    {

    }

    void Update()
    {
        myGame = (MyGame)game;
        player = myGame.GetPlayer();

        base.Update();
    }

    public override void Aiming()
    {
        Vec2 desDirection = player.position - position;
        float bulletReach = desDirection.Length() / base.bulletSpeed;
        desDirection += player.velocity * bulletReach;
        entityBarrel.rotation = desDirection.GetAngleDegrees();
    }

    public override void Movement()
    {

    }
    public override void Shooting()
    {
        int fireRate = 50; 
        bool forAllLines = false; 
        for (int i = 0; i < myGame.GetNumberOfLines(); i++)
        {
            NLineSegment line = myGame.GetLine(i);
            if (Vec2.IntersectionPoint(player.position, position, line.end, line.start))
            {
                forAllLines = false;
                break;
            }else
            forAllLines = true;
        }
        if (forAllLines == true)
        {
            time++;
            if(time % fireRate == 0)
            {
                base.Shooting();
                time = 0;
            }
        }
    }
}
