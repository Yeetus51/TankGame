using System;
using GXPEngine;
using System.Drawing;
using System.Collections.Generic;

public class MyGame : Game
{
	bool _stepped = false;
	bool _paused = false;
	int _stepIndex = 0;
	int _startSceneNumber = 0;

	Canvas _lineContainer = null;

	List<Ball> _movers;
	List<NLineSegment> _lines;

	Player player;
	Enemy enemy; 

	public int GetNumberOfLines() {
		return _lines.Count;
	}

	public NLineSegment GetLine(int index) {
		if (index >= 0 && index < _lines.Count) {
			return _lines[index];
		}
		return null;
	}

	public int GetNumberOfMovers() {
		return _movers.Count;
	}
	public Player GetPlayer()
    {
		return player;
    }

	public Ball GetMover(int index) {
		if (index >= 0 && index < _movers.Count) {
			return _movers[index];
		}
		return null;
	}

	public void DrawLine(Vec2 start, Vec2 end) {
		_lineContainer.graphics.DrawLine(Pens.White, start.x, start.y, end.x, end.y);
	}

	public MyGame() : base(1280, 720, false, false)
	{
		_lineContainer = new Canvas(width, height);
		AddChild(_lineContainer);

		targetFps = 60;

		_movers = new List<Ball>();
		_lines = new List<NLineSegment>();

		LoadScene(_startSceneNumber);


		UnitTests();
	}

	void AddLine(Vec2 start, Vec2 end) {
		NLineSegment line = new NLineSegment(start, end, 0xff00ff00, 4);
		AddChild(line);
		_lines.Add(line);
	}
	void KeyControlls()
	{

        if (Input.GetKeyDown('R')) DestroyBullets();
		//if (Input.GetKeyDown('F')) RemoveBullet(2);

/*		if (Input.GetKeyDown(Key.D))
		{
			Ball.drawDebugLine ^= true;
		}

		if (Input.GetKeyDown(Key.S))
		{
			_stepped ^= true;
		}*/

		for (int i = 0; i < 10; i++)
		{
			if (Input.GetKeyDown(48 + i))
			{
				LoadScene(i);
			}
		}

		targetFps = Input.GetKey(Key.SPACE) ? 5 : 60;

	}
	void DestroyBullets()
	{
		do
		{
			foreach (Ball mover in _movers)
			{
				_movers.Remove(mover);
				mover.Destroy();
				break;
			}
		} while (_movers.Count > 0);
	}

	
	public void AddBullet(int radius, Vec2 position, Vec2 velocity)
	{
		_movers.Add(new Ball(radius, position, velocity));
		AddChild(_movers[_movers.Count - 1]);
	}
	void AddlineCorners()
	{
		for (int i = 0; i < _lines.Count; i++)
		{
			NLineSegment line = GetLine(i);
			_movers.Add(new Ball(5, line.start, new Vec2(), false));
			AddChild(_movers[_movers.Count - 1]);
		}
	}
	void AddEnemy(Vec2 pPos)
    {
		Enemy enemy = new Enemy(pPos, 25, 230);
		AddChild(enemy);
	}
	void PolygonMaker(Vec2[] polyGon)
    {
		if(polyGon.Length < 2)
        {
            Console.WriteLine("Polygon with less than 2 points can't be made!");
			return;
        }

        for (int i = 1; i < polyGon.Length; i++)
        {
			AddLine(polyGon[i - 1], polyGon[i]);
		}
		AddLine(polyGon[polyGon.Length - 1], polyGon[0] );
	}

	void LoadScene(int sceneNumber) {
		_startSceneNumber = sceneNumber;
		// remove previous scene:
		foreach (Ball mover in _movers) {
			mover.Destroy();
		}
		_movers.Clear();
		foreach (NLineSegment line in _lines) {
			line.Destroy();
		}
		_lines.Clear();

		// boundary:

		PolygonMaker(new Vec2[]{new Vec2 (50,height-50), new Vec2(width-50,height-50), new Vec2(width-50,50), new Vec2(50,50)}); 

		switch (sceneNumber) {			
			default: // one moving ball (low speed), one fixed ball.
				Ball.acceleration.SetXY(0, 0);

				//PolygonMaker(new Vec2[] {new Vec2(250, 250) , new Vec2(350,300), new Vec2(450,250), new Vec2(350,350)});

				PolygonMaker(new Vec2[] { new Vec2(150, 100), new Vec2(250,100), new Vec2(250,250), new Vec2(220,250), new Vec2(220,250), new Vec2(180,180), new Vec2(150,180)});
				PolygonMaker(new Vec2[] { new Vec2(250, 400), new Vec2(400, 400), new Vec2(400, 430), new Vec2(350, 430), new Vec2(270, 500), new Vec2(270, 600), new Vec2(250, 600) });
				PolygonMaker(new Vec2[] { new Vec2(700, 500), new Vec2(750, 500) , new Vec2(750,670), new Vec2(700,670) });
				PolygonMaker(new Vec2[] { new Vec2(700, 50), new Vec2(750, 50), new Vec2(750, 270-50), new Vec2(700, 270-50) });
				PolygonMaker(new Vec2[] { new Vec2(900, 50+100), new Vec2(950, 50+100), new Vec2(950, 270+300), new Vec2(900, 270+300)});

				//AddLine( new Vec2(350, 300), new Vec2(250, 250));
				//PolygonMaker(new Vec2[] { new Vec2(500, 250) }); //, new Vec2(600, 100) , new Vec2(800, 300) });

				for (int i = 0; i < 12; i++)
                {
					_movers.Add(new Ball(10,new Vec2(715,240 + i *22)));
					_movers.Add(new Ball(10, new Vec2(735, 240 + i * 22)));
				}
				AddEnemy(new Vec2(400, 500));
				AddEnemy(new Vec2(1000, 600));

				player = new Player(new Vec2(150, 300), 25, 100);
				AddChild(player);
				break;
		}		
		AddlineCorners();

		_stepIndex = -1;
		foreach (Ball b in _movers) {
			AddChild(b);
		}
	}

	/****************************************************************************************/


	void HandleInput() {
		targetFps = Input.GetKey(Key.SPACE) ? 5 : 60;
		if (Input.GetKeyDown (Key.UP)) {
			Ball.acceleration.SetXY (0, -1);
		}
		if (Input.GetKeyDown (Key.DOWN)) {
			Ball.acceleration.SetXY (0, 1);
		}
		if (Input.GetKeyDown (Key.LEFT)) {
			Ball.acceleration.SetXY (-1, 0);
		}
		if (Input.GetKeyDown (Key.RIGHT)) {
			Ball.acceleration.SetXY (1, 0);
		}
		if (Input.GetKeyDown (Key.BACKSPACE)) {
			Ball.acceleration.SetXY (0, 0);
		}
		if (Input.GetKeyDown (Key.S)) {
			_stepped ^= true;
		}
		if (Input.GetKeyDown (Key.D)) {
			Ball.drawDebugLine ^= true;
		}
		if (Input.GetKeyDown (Key.P)) {
			_paused ^= true;
		}
		if (Input.GetKeyDown (Key.B)) {
			Ball.bounciness = 1.5f - Ball.bounciness;
		}
		if (Input.GetKeyDown(Key.W)) {
			Ball.wordy ^= true;
		}
		if (Input.GetKeyDown (Key.C)) {
			_lineContainer.graphics.Clear (Color.Black);
		}
		if (Input.GetKeyDown (Key.R)) {
			LoadScene (_startSceneNumber);
		}
		for (int i = 0; i< 10; i++) {
			if (Input.GetKeyDown (48 + i)) {
				LoadScene (i);
			}
		}
	}

	void StepThroughMovers() {
		if (_stepped) { // move everything step-by-step: in one frame, only one mover moves
			_stepIndex++;
			if (_stepIndex >= _movers.Count) {
				_stepIndex = 0;
			}
			if (_movers [_stepIndex].moving) {
				_movers [_stepIndex].Step ();
			}
		} else { // move all movers every frame
			foreach (Ball mover in _movers) {
				if (mover.moving) {
					mover.Step ();
				}
			}
		}
	}


	void Update()
	{
		//HandleInput();

		if (!_paused)
		{
			StepThroughMovers();
		}

		KeyControlls();


	}
	static void Main() {
		new MyGame().Start();
	}
	static bool Approximate(float a, float b, float errorMargin = 0.01f)
	{
		return Mathf.Abs(a - b) < errorMargin;
	}
	static bool Approximate(Vec2 vector, Vec2 vector2, float errorMargin = 0.01f)
	{
		bool x = Approximate(vector.x, vector2.x, errorMargin);
		bool y = Approximate(vector.y, vector2.y, errorMargin);
		return (x && y);
	}
	void UnitTests()
	{
		Console.WriteLine("Approximate ok? " + Approximate(7.5f, 7.5001f, 0.1f));

		Vec2 length = new Vec2(8, 6);
		float lengthA = 10;
		Console.WriteLine("Is Length ok? " + Approximate(length.Length(), lengthA));

		Vec2 normalize = new Vec2(-5, 10);
		Vec2 normalizeA = new Vec2(-0.447f, 0.8944f);
		normalize.Normalize();
		Console.WriteLine("Is Normalize ok? " + Approximate(normalize, normalizeA));


		Vec2 normalized = new Vec2(2, -12.64f);
		Vec2 normalizedA = new Vec2(0.1562f, -0.98771f);
		Console.WriteLine("Is Normalized ok? " + Approximate(normalized.Normalized(), normalizedA));

		Vec2 setLength = new Vec2(0.8f, 0.6f);
		setLength.SetLength(10);
		Console.WriteLine("Is SetLength ok? " + Approximate(setLength.Length(), 10));

		Vec2 v1 = new Vec2(2, 5);
		Vec2 v2 = new Vec2(8, 3);
		Vec2 v3 = new Vec2(2, 3);
		Vec2 v4 = new Vec2(7, 6);
		Vec2 opp = (v1 + v2 * v3) / v4;
		Vec2 oppA = new Vec2(2.57142f, 2.3333f);
		Console.WriteLine("Are Operators ok ? " + Approximate(opp, oppA));

		float Deg2Rad = Vec2.Deg2Rad(90);
		float Deg2RadA = Mathf.PI / 2;
		Console.WriteLine("Is Deg2Rad ok ? " + Approximate(Deg2Rad, Deg2RadA));

		float Rad2Deg = Vec2.Rad2Deg(Mathf.PI / 2);
		float Rad2DegA = 90;
		Console.WriteLine("Is Rad2Deg ok ? " + Approximate(Rad2Deg, Rad2DegA));

		float getUnitVector = Mathf.PI / 4;
		Vec2 getUnitVectorA = new Vec2(0.707f, 0.707f);
		Console.WriteLine("Is GetUnitVectorRad ok? " + Approximate(Vec2.GetUnitVectorRad(getUnitVector), getUnitVectorA));

		float getUnitVectorDeg = 45;
		Console.WriteLine("Is GetUnitVectorDeg ok? " + Approximate(Vec2.GetUnitVectorDeg(getUnitVectorDeg), getUnitVectorA));

		Console.WriteLine("Is RandomUnitvector ok? " + Approximate(Vec2.RandomUnitVector().Length(), 1));

		Vec2 setAngleRadians = new Vec2(6, 8);
		Vec2 setAngleRadiansA = new Vec2(0, 10);
		setAngleRadians.SetAngleRadians(Mathf.PI / 2);
		Console.WriteLine("Is SetAngleRadians ok? " + Approximate(setAngleRadians, setAngleRadiansA));

		Vec2 getAngleRadians = new Vec2(15, 15);
		float getAngleRadiansA = Mathf.PI / 4;
		Console.WriteLine("Is GetAngleRadians ok? " + Approximate(getAngleRadians.GetAngleRadians(), getAngleRadiansA));

		Vec2 rotateRadians = new Vec2(8, 6);
		Vec2 rotateRadiansA = new Vec2(-6, 8);
		rotateRadians.RotateRadians(Mathf.PI / 2);
		Console.WriteLine("Is RotateRadians ok? " + Approximate(rotateRadians, rotateRadiansA));

		Vec2 point = new Vec2(2, 11);
		Vec2 rotateAroundRadians = new Vec2(3, 12);
		Vec2 rotateAroundRadiansA = new Vec2(1, 12);
		rotateAroundRadians.RotateAroundRadians(point, Mathf.PI / 2);
		Console.WriteLine("Is RotateAroundRadians ok? " + Approximate(rotateAroundRadians, rotateAroundRadiansA));

		Vec2 line1 = new Vec2(13, 5);
		Vec2 line2 = new Vec2(5, 0);
		float dot = line1.Dot(line2.Normalized());
		float dotA = 13;
		Console.WriteLine("Is Dot ok? " + Approximate(dot, dotA));

		float dotAngleBetweenRadians = Vec2.DotAngleBetweenRadians(line1, line2);
		float dotAngleBeteeenRadiansA = 0.367173f;
		Console.WriteLine("Is DotAngleBetweenRadians ok? " + Approximate(dotAngleBetweenRadians, dotAngleBeteeenRadiansA));
	}

}