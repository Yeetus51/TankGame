﻿using System;
using GXPEngine;

public class Ball : EasyDraw
{
	// These four public static fields are changed from MyGame, based on key input (see Console):
	public static bool drawDebugLine = false;
	public static bool wordy = false;
	public static float bounciness = 1f;
	// For ease of testing / changing, we assume every ball has the same acceleration (gravity):
	public static Vec2 acceleration = new Vec2 (0, 0);

	int collisionCount = 0; 

	public Vec2 velocity;
	public Vec2 position;

	public readonly int radius;
	public readonly bool moving;

	public float Mass {
		get {
			return radius * radius * _density;
		}
	}

	Vec2 _oldPosition;
	Arrow _velocityIndicator;

	float _density = 1;

	public Ball (int pRadius, Vec2 pPosition, Vec2 pVelocity=new Vec2(), bool moving=true) : base (pRadius*2 + 1, pRadius*2 + 1)
	{
		radius = pRadius;
		position = pPosition;
		velocity = pVelocity;
		this.moving = moving;

		position = pPosition;
		UpdateScreenPosition ();
		SetOrigin (radius, radius);

		Draw (230, 200, 0);

		_velocityIndicator = new Arrow(position, new Vec2(0,0), 10);
		AddChild(_velocityIndicator);
	}

	void Draw(byte red, byte green, byte blue) {
		Fill (red, green, blue);
		Stroke (red, green, blue);
		Ellipse (radius, radius, 2*radius, 2*radius);
	}

	void UpdateScreenPosition() {
		x = position.x;
		y = position.y;
	}

	public void Step () {
		_oldPosition = position;

		velocity += acceleration;
		position += velocity;
        if (moving)
        {
			CollisionInfo firstCollision = FindEarliestCollision();
			if (firstCollision != null) {
				ResolveCollision(firstCollision);
			}
        }

		UpdateScreenPosition();

		ShowDebugInfo();
	}

	float TOI(Vec2 RelativePos, float Radius , float otherRad)
    {
		float a = Mathf.Pow(velocity.Length(), 2);
		float b = 2 * RelativePos.Dot(velocity);
		float f = radius + otherRad;
		f = Mathf.Pow(f, 2);
		float c = Mathf.Pow(RelativePos.Length(), 2);
		c = c - f; 
		float D = (b*b) - (4*a*c);

		if (a == 0) return 1;
		if (D < 0) return 1;

		float t = (b * -1) - Mathf.Sqrt(D);
		a = 2 * a;
		t = t / a; 

		return t;
	}

	CollisionInfo FindEarliestCollision() {

		float newBTOI = 90;
		float newLTOI = 90;
		Ball newBallMover = new Ball(0, new Vec2(), new Vec2(),false);
		NLineSegment newLineSeg = new NLineSegment(new Vec2(0, 0), new Vec2(0, 0));

		MyGame myGame = (MyGame)game;
		for (int i = 0; i < myGame.GetNumberOfMovers(); i++) {
			Ball mover = myGame.GetMover(i);
			if (mover != this) {
				Vec2 relativePos = _oldPosition - mover.position;
				float TOI = this.TOI(relativePos, radius, mover.radius);
				if (TOI > 1 || TOI < 0) // If not colliding
					continue;

				if (Mathf.Abs(TOI) < newBTOI && TOI < 1) // Smallest Ball Time of Impact
				{
					newBallMover = mover;
					newBTOI = TOI;
				}
			}
		}

		for (int i = 0; i < myGame.GetNumberOfLines(); i++) 
		{
			NLineSegment other = myGame.GetLine(i); 
			if (other != null)
			{
				Vec2 Line = other.end - other.start;
				float ballDistance = (other.end - position).Dot(Line.Normal());
				float oldBallDistance = (other.end - _oldPosition).Dot(Line.Normal());
				float LSCheck = (other.end - position).Dot(Line.Normalized());
				float lineLength = Line.Length();

				if (LSCheck > lineLength || LSCheck <= 0) continue; // if outside line segment 


				if (oldBallDistance <= 0) continue; // if on other side of line


				if(ballDistance < radius) // Collision
                {
					float pB = Mathf.Abs(ballDistance) + oldBallDistance; 
					float pA = oldBallDistance - radius; 
					float TOI = pA / pB;

					if (TOI < newLTOI) // find smallest time of impact
					{
						newLineSeg = other;
						newLTOI = TOI;
					}				
                }
			}
		}

		GameObject gameObject;
		Vec2 LineNormal;
		bool moving;
		float toi;

		if (Mathf.Abs(newBTOI) > Mathf.Abs(newLTOI)) //Ball or Line //Smallest time of impact out of both of them
		{
			toi = newLTOI;
			Vec2 Line = newLineSeg.start - newLineSeg.end;
			LineNormal = Line.Normal();
			gameObject = newLineSeg;
			moving = false;
		}
		else
		{
			toi = newBTOI;
			Vec2 POI = _oldPosition + velocity * toi; 
			Vec2 Normal = (POI - newBallMover.position).Normalized();
			LineNormal = Normal;
			gameObject = newBallMover;
			moving = newBallMover.moving;
		}

        if (toi >= 0 && toi < 1)
        {
			return new CollisionInfo(LineNormal, gameObject, toi, moving);
        }
		return null;
	}



	void ResolveCollision(CollisionInfo col) {


		position = _oldPosition + velocity * col.timeOfImpact;

		if(!col.moving) //if its line or corner: Simple reflect
		{
			velocity.Reflect(Ball.bounciness, col.normal);
			return; 
		}

		if(col.other is Ball otherBall)
        {
			Vec2 relativePos = _oldPosition - otherBall.position;
			Vec2 relativeVel = velocity - otherBall.velocity;
            if (Vec2.DotAngleBetweenDegrees(relativePos, relativeVel) < 90) // Fake Collision
                return;

			Vec2 CoM = Vec2.CoM(velocity, otherBall.velocity, Mass, otherBall.Mass);
			velocity.VelocityReflect(CoM, Ball.bounciness , col.normal); 

			otherBall.velocity.VelocityReflect(CoM, Ball.bounciness, col.normal);
        }
	}

	void ShowDebugInfo() {
		if (drawDebugLine) {
			((MyGame)game).DrawLine (_oldPosition, position);
		}
		_velocityIndicator.startPoint = position;
		_velocityIndicator.vector = velocity;
	}
}

