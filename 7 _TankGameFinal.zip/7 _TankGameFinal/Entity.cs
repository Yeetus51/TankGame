﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GXPEngine; 

public abstract class Entity : GameObject
{
    public Vec2 acceleration;
    public Vec2 velocity;
    public Vec2 position;
    Vec2 _oldPosition;
    public int radius;
    public float bulletSpeed = 5;
    public float friction = 0.95f;
    EasyDraw entityBody;
    public EasyDraw entityBarrel;

    public Entity(Vec2 pPos, int pRadius, Int32 pColor)
    {
        position = pPos;
        radius = pRadius;
        entityBody = new EasyDraw(radius * 2, radius * 2, false);
        entityBody.Fill(pColor);
        entityBody.NoStroke();
        entityBody.SetOrigin(entityBody.width / 2, entityBody.height / 2);
        entityBody.Ellipse(entityBody.width / 2, entityBody.height / 2, radius * 2, radius * 2);
        AddChild(entityBody);

        entityBarrel = new EasyDraw(Mathf.Round(radius * 1.3f), Mathf.Round(radius * 0.3f), false);
        entityBarrel.Clear(200, 0, 0);
        entityBarrel.NoStroke();
        entityBarrel.SetOrigin((entityBarrel.width / 10), entityBarrel.height / 2);
        entityBody.AddChild(entityBarrel);
    }

    public void Update()
    {
        Movement();
        Aiming();
        Shooting();


        _oldPosition = position;
        acceleration.SetLength(0.1f);

        velocity += acceleration;
        position += velocity;

        velocity *= friction;


        SimplePositionResolve();
        UpdatePositionsOnScreen();
        acceleration = new Vec2(0, 0);
    }
    void UpdatePositionsOnScreen()
    {
        x = position.x;
        y = position.y;
    }
    public virtual void Movement()
    {
        if (Input.GetKey('W')) acceleration = new Vec2(acceleration.x, -0.1f);
        if (Input.GetKey('A')) acceleration = new Vec2(-0.1f, acceleration.y);
        if (Input.GetKey('S')) acceleration = new Vec2(acceleration.x, 0.1f);
        if (Input.GetKey('D')) acceleration = new Vec2(0.1f, acceleration.y);
    }
    public virtual void Aiming()
    {
        Vec2 desDirection = new Vec2(Input.mouseX - position.x, Input.mouseY - position.y);
        entityBarrel.rotation = desDirection.GetAngleDegrees();
    }
    public virtual void Shooting()
    {
        MyGame myGame = (MyGame)game;
        Vec2 bulletDirection = Vec2.GetUnitVectorDeg(entityBarrel.rotation);
        Vec2 bulletPos = position + (bulletDirection * entityBarrel.width);
        myGame.AddBullet(Mathf.Round(radius * 0.16f), bulletPos, bulletDirection * bulletSpeed);
    }

    void SimplePositionResolve()
    {
        MyGame myGame = (MyGame)game;
        for (int i = 0; i < myGame.GetNumberOfMovers(); i++)
        {
            Ball mover = myGame.GetMover(i);
            if (mover != null)
            {
                Vec2 relativePosition = position - mover.position;
                Vec2 Normal = relativePosition.Normalized();
                if (relativePosition.Length() < (radius + mover.radius))
                {
                    if (!mover.moving)
                    {
                        position += Normal * (radius + mover.radius - relativePosition.Length());
                    }
                    else Destroy();
                }
            }
        }

        for (int j = 0; j < myGame.GetNumberOfLines(); j++)
        {
            NLineSegment other = myGame.GetLine(j);
            if (other != null)
            {
                Vec2 Line = other.start - other.end;
                float ballDistance = Mathf.Abs((position - other.end).Dot(Line.Normal()));
                if (ballDistance < radius)
                {
                    Vec2 pos1 = other.start - position;
                    Vec2 pos2 = other.end - position;
                    float dis1 = Mathf.Abs(pos1.Dot(Line.Normalized()));
                    float dis2 = Mathf.Abs(pos2.Dot(Line.Normalized()));
                    float lineLength = Line.Length();
                    if (dis1 > lineLength || dis2 > lineLength)
                    {
                        continue;
                    }
                    position += Line.Normal() * (radius - ballDistance);
                }
            }
        }
    }
}
