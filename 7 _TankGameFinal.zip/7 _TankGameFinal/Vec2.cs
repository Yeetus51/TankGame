﻿using System;
using GXPEngine;	// For Mathf

public struct Vec2
{
    public float x;
    public float y;

    public Vec2(float pX = 0, float pY = 0)
    {
        x = pX;
        y = pY;
    }

    public override string ToString()
    {
        return String.Format("({0},{1})", x, y);
    }

    public void Add(Vec2 other)
    {
        x += other.x;
        y += other.y;
    }

    public float Length()
    {
        return Mathf.Sqrt(x * x + y * y);
    }

    public void Normalize()
    {
        if (x == 0 && y == 0)
        {
            // nothing
        }
        else
        {
            float length = Length();
            x = x / length;
            y = y / length;
        }
    }

    public Vec2 Normalized()
    {
        float length = Length();
        if (length != 0)
        {
            return new Vec2(x / length, y / length);

        }
        return new Vec2(0, 0);
    }

    public void SetLength(float scale)
    {
        this.Normalize();
        this.x *= scale;
        this.y *= scale;
    }

    public void SetXY(float pX, float pY)
    {
        x = pX;
        y = pY;
    }
    public void SetXY(float pPos)
    {
        SetXY(pPos, pPos);
    }
    public void SetXY(Vec2 pPos)
    {
        SetXY(pPos.x, pPos.y);
    }


    public static Vec2 operator +(Vec2 left, Vec2 right)
    {
        return new Vec2(left.x + right.x, left.y + right.y);
    }

    public static Vec2 operator -(Vec2 left, Vec2 right)
    {
        return new Vec2(left.x - right.x, left.y - right.y);
    }

    public static Vec2 operator *(Vec2 left, Vec2 right)
    {
        return new Vec2(left.x * right.x, left.y * right.y);
    }
    public static Vec2 operator /(Vec2 left, Vec2 right)
    {
        return new Vec2(left.x / right.x, left.y / right.y);
    }
    public static Vec2 operator /(Vec2 left, float right)
    {
        return new Vec2(left.x / right, left.y / right);
    }
    public static Vec2 operator /(float left, Vec2 right)
    {
        return new Vec2(left / right.x, left / right.y);
    }



    public static Vec2 operator *(Vec2 left, float right)
    {
        return new Vec2(left.x * right, left.y * right);
    }
    public static Vec2 operator *(float left, Vec2 right)
    {
        return new Vec2(left * right.x, left * right.y);
    }



    public static float Deg2Rad(float degree)
    {
        return degree * Mathf.PI / 180;
    }
    public static float Rad2Deg(float rad)
    {
        return rad * 180 / Mathf.PI;
    }

    public static Vec2 GetUnitVectorRad(float rad) //Creates new vector in direction of Radian given 
    {
        Vec2 GUVR = new Vec2(Mathf.Cos(rad), Mathf.Sin(rad));
        return GUVR;
    }
    public static Vec2 GetUnitVectorDeg(float degrees) //Creates new vector in direction of degrees given 
    {
        return GetUnitVectorRad(Deg2Rad(degrees));
    }
    public static Vec2 RandomUnitVector() //Creates new vector in random direction
    {
        float rand = Utils.Random(0, Mathf.PI * 2);
        return GetUnitVectorRad(rand);
    }

    public void SetAngleRadians(float rad)
    {
        Vec2 angle = GetUnitVectorRad(rad);
        angle.SetLength(this.Length());
        this.SetXY(angle);
    }
    public void SetAngleDegrees(float degree)
    {
        SetAngleRadians(Deg2Rad(degree));
    }

    public float GetAngleRadians()
    {
        return Mathf.Atan2(this.y, this.x);
    }
    public float GetAngleDegrees()
    {
        return Rad2Deg(GetAngleRadians());
    }

    public void RotateRadians(float rad)
    {
        this.SetXY(Mathf.Cos(rad) * this.x - Mathf.Sin(rad) * this.y, Mathf.Cos(rad) * this.y + Mathf.Sin(rad) * this.x);
    }
    public void RotateDegrees(float degree)
    {
        RotateRadians(Deg2Rad(degree));
    }
    public void RotateAroundRadians(Vec2 vector, float rad) //Rotates around a point in radians 
    {
        this -= vector;
        this.RotateRadians(rad);
        this += vector;
    }
    public void RotateAroundDegrees(Vec2 vector, float degree) //Rotates around a point in degrees 
    {
        RotateAroundRadians(vector, Deg2Rad(degree));
    }

    public static float FindAngleBetweenRadians(Vec2 v1, Vec2 v2)
    {
        v2.RotateRadians(-v1.GetAngleRadians());
        return v2.GetAngleRadians();
    }
    public static float FindAngleBetweenDegrees(Vec2 v1, Vec2 v2)
    {
        return Rad2Deg(FindAngleBetweenRadians(v1, v2));
    }
    public static float FindAngleBetweenRadians(float r1, float r2)
    {
        Vec2 v1 = GetUnitVectorRad(r1);
        Vec2 v2 = GetUnitVectorRad(r2);
        return FindAngleBetweenRadians(v1, v2);
    }
    public static float FindAngleBetweenDegrees(float d1, float d2)
    {
        Vec2 v1 = GetUnitVectorDeg(d1);
        Vec2 v2 = GetUnitVectorDeg(d2);
        return FindAngleBetweenDegrees(v1, v2);
    }

    public float Dot(Vec2 other)
    {
        float dot = this.x * other.x + this.y * other.y;
        return dot;
    }

    public static float DotAngleBetweenRadians(Vec2 v1 , Vec2 v2)
    {
        return Mathf.Acos(v1.Dot(v2) / (v1.Length() * v2.Length()));
    }
    public static float DotAngleBetweenDegrees(Vec2 v1, Vec2 v2)
    {
        return Rad2Deg(DotAngleBetweenRadians(v1, v2));
    }

    public Vec2 Normal()
    {
        float vX = -this.y;
        float vY = this.x;
        return new Vec2(vX, vY).Normalized();
    }

    public void Reflect(float bounciness, Vec2 Normal)
    {
        this = this - (1 + bounciness) * this.Dot(Normal) * Normal;
    }

    public static Vec2 CoM(Vec2 v1, Vec2 v2, float m1 , float m2)
    {
        return (v1 * m1 + v2 * m2) / (m1 + m2);  
    }

    public void VelocityReflect (Vec2 CoM , float bounciness, Vec2 Normal)
    {
        this = this - (1 + bounciness) * ((this - CoM).Dot(Normal) * Normal); 
    }

    public void COR (float bouciness , Vec2 normal)
    {
        this = this - (1 + bouciness) * this.Dot(normal) * normal;  
    }

    public static bool IntersectionPoint(Vec2 p1, Vec2 p2, Vec2 p3, Vec2 p4)
    {
        float denominator = (p1.x - p2.x) * (p3.y - p3.y) - (p1.y - p2.y) * (p3.x - p4.x);
        float topT = (p1.x - p3.x) * (p3.y - p4.y) - (p1.y - p3.y) * (p3.x - p4.x);
        float topU = (p1.x - p3.x) * (p1.y - p2.y) - (p1.y - p3.y) * (p1.x - p2.x);

        float t = topT / denominator;
        float u = topU / denominator;
        Vec2 pos = new Vec2(p1.x + t * (p2.x - p1.x), p1.y + t * (p2.y - p1.y));

        if(t > 0 && t < 1 && u > 0 && u < 1)
        {
            return true;
        }
        //return pos;

        return false;
    }

}

